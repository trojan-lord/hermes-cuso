---
name: system-maintenance
description: "System cleanup and maintenance for Arch-based Linux — disk analysis, cache purging, service hygiene. Scan first, present plan, execute on approval."
tags: [linux, arch, cleanup, maintenance, disk, cache, pacman]
related_skills: [linux-desktop]
---

# System Maintenance

Disk cleanup, cache purging, and system hygiene for Arch-based Linux (CachyOS, Arch, Manjaro).

---

## Workflow: Full System Update

**Trigger:** User asks to update the system, "update everything", or "system package update."

### Step 1: Run all package managers in sequence

```bash
# 1. System packages (pacman)
sudo pacman -Syu --noconfirm 2>&1 | tail -20

# 2. AUR packages
yay -Sua --noconfirm 2>&1 | tail -10

# 3. npm global packages
npm update -g 2>&1 | tail -10

# 4. Python packages (uv if available, else pip)
uv pip list --outdated 2>/dev/null | tail -10
# Then upgrade each outdated package:
uv pip install --upgrade <package1> <package2> ...
```

### Step 2: Check for kernel updates

If pacman output shows kernel/initramfs upgrades, recommend reboot:
```bash
# Check if reboot needed
check-reboot 2>/dev/null || echo "Reboot recommended if kernel was updated"
```

### Pitfalls

- `npm update -g` only updates packages installed globally. Local project deps need `npm update` in the project dir.
- `uv pip list --outdated` checks against PyPI index. Packages installed via system pip vs uv may show different results.
- Pacman `-Syu` is the safe full upgrade. Never use `-Sy` alone (partial upgrade breaks things).
- After kernel updates, always recommend reboot. The user expects this.

---

## Workflow: Disk Cleanup

**Trigger:** User asks to clean up disk space, do maintenance, or "clean up the computer."

### Step 1: Scan

Run three parallel scans — disk usage overview, package manager caches, and home directory breakdown:

```bash
# Disk overview
df -h / && echo "" && du -sh ~/.* 2>/dev/null | sort -rh | head -20

# Package manager + tool caches
du -sh /var/cache/pacman/pkg 2>/dev/null      # pacman cache
du -sh ~/.cache/yay 2>/dev/null               # AUR helper cache
du -sh ~/.cache/paru 2>/dev/null
du -sh ~/.cache/pip 2>/dev/null
du -sh ~/.cache/uv 2>/dev/null
du -sh ~/.local/share/pnpm/store 2>/dev/null
du -sh ~/.npm/_cacache 2>/dev/null            # npm cache
journalctl --disk-usage 2>/dev/null           # systemd journals
du -sh /tmp 2>/dev/null
du -sh ~/.local/share/Trash 2>/dev/null

# Home directory breakdown
du -sh ~/.local/share/* 2>/dev/null | sort -rh | head -15
du -sh ~/.cache/* 2>/dev/null | sort -rh | head -10
```

### Step 2: Present Plan

Show a table with three columns: **What**, **Size**, **Risk**.

- Group by category (package caches, tool caches, logs, app data)
- Mark items as None/Low/Medium/High risk
- Call out anything ambiguous (old Wine prefixes, dev tool caches, game compat layers)
- Show total recoverable estimate

**User preference:** Present findings concisely. The user wants to see the plan before anything gets deleted. Do NOT auto-clean without asking.

### Step 3: Ask About Ambiguous Items

Before executing, ask the user about items where intent is unclear:
- Wine prefix (do they use Wine apps?)
- Dev tool caches (bun, npm, cargo — will they need them?)
- Large app directories (Steam games, Lutris)

### Step 4: Execute

Run cleanup commands in parallel where possible. Report results per item.

### Step 5: Verify

Show final disk usage and total freed.

---

## Cleanup Commands Reference

### Pacman Cache

```bash
# Keep 2 most recent versions (safe, recommended)
sudo paccache -rk2

# Remove ALL cached versions except currently installed
sudo paccache -ruk0

# Nuclear: remove everything
sudo pacman -Scc
```

Typical savings: 10-25G on systems that haven't been cleaned.

### NPM Cache

```bash
npm cache clean --force
```

### Bun Cache

```bash
rm -rf ~/.bun/install/cache/*
```

### Pip/UV Cache

```bash
pip cache purge
uv cache clean
```

### PNPM Store

```bash
pnpm store prune
```

### Hermes Logs

```bash
rm -rf ~/.hermes/logs/*.log
```

### Thumbnails

```bash
rm -rf ~/.cache/thumbnails/*
```

### Systemd Journals

```bash
# Keep only last 3 days
sudo journalctl --vacuum-time=3d

# Keep only last 100M
sudo journalctl --vacuum-size=100M
```

### Wine Prefix (if unused)

```bash
rm -rf ~/.wine
rm -rf ~/.local/share/applications/wine*
```

---

## Items to NEVER Clean Without Asking

- `~/.opencode` — may contain contingency reinstall binaries
- `~/.local/share/Steam` — game data
- `~/.cargo` — Rust toolchain
- `~/.local/share/uv` — Python toolchain
- `~/.local/share/zed` — editor data
- `~/.hermes` — agent data (logs only, not the whole dir)
- Any dev project directories

---

## Quick Tunnel (Cloudflared)

When you need to share a localhost service externally without account setup:

```bash
# Download (one-time)
curl -sL https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /tmp/cloudflared
chmod +x /tmp/cloudflared

# Run quick tunnel
/tmp/cloudflared tunnel --url http://localhost:PORT
```

Output includes a `https://*.trycloudflare.com` URL. No account, no config. Tunnel dies when the process stops.

**Pitfall:** The binary is ~30MB and downloaded to /tmp. It won't persist across reboots. For persistent tunnels, install cloudflared properly and create a named tunnel with a Cloudflare account.

### Hosting Multiple Sites

For serving multiple directories (e.g., website variants), start a separate HTTP server + tunnel per site:

```bash
# Start servers on different ports
cd /path/to/site-a && python3 -m http.server 8080 &
cd /path/to/site-b && python3 -m http.server 8081 &

# Start a tunnel per port
/tmp/cloudflared tunnel --url http://localhost:8080  # → URL-A
/tmp/cloudflared tunnel --url http://localhost:8081  # → URL-B
```

Each tunnel gets its own ephemeral `*.trycloudflare.com` URL. Use `process(action='log')` to extract URLs from the tunnel output.

See `references/cloudflared-tunneling.md` for details.

---

## Workflow: Orphaned Package Audit

**Trigger:** User asks to clean up packages, remove orphans, or "clean redundant packages."

### Step 1: List Orphans

```bash
# Full list with versions
pacman -Qdt 2>/dev/null

# Count
pacman -Qdtq 2>/dev/null | wc -l
```

### Step 2: Verify Each Package

For every orphan, check three things:

```bash
# 1. Does anything depend on it?
pacman -Qi "$pkg" | grep "Required By"

# 2. Is the binary still installed and in PATH?
which "$pkg" 2>/dev/null

# 3. Is it actually in use? (check running processes, pip packages, etc.)
```

### Step 3: Classify

Split into categories:
- **Definitely safe** — no dependents, not in PATH, not actively used, or superseded by newer version
- **HOLD — actively used** — binary found, user has it installed for a reason even if orphaned
- **HOLD — system-relevant** — audio/display/network libs that look orphaned but serve runtime roles

### Step 4: Present Findings

Show three tables with clear headers: "Definitely safe", "Hold — you're using these", "Hold — system-relevant". Explain WHY each item is in its category.

**User preference:** Always present findings before removing anything. The user explicitly wants double-checking before orphan removal. Do NOT auto-remove without approval.

### Step 5: Ask Before Removing

Use clarify tool or ask directly which categories to remove. Default to removing only the "definitely safe" set unless user says otherwise.

### Step 6: Execute & Verify

```bash
sudo pacman -Rns <package_names>
```

Verify system still boots/works after removal.

**Key pitfall:** Orphans include tools the user installed deliberately (bun, eslint, pyright, rust-analyzer) that just happen to have no dependents. Always flag these as "actively used" even though they're orphans. The user will be annoyed if you remove their dev tools because pacman said they were orphans.

---

## Workflow: Redundant File Scan

**Trigger:** User asks to check for leftover files, duplicates, stale configs, or "scan for redundant stuff."

### Step 1: Scan Categories (parallel)

```bash
# Leftover config dirs (apps no longer installed)
for d in ~/.config/*/; do
  name=$(basename "$d")
  if ! pacman -Qi "$name" &>/dev/null; then
    du -sh "$d" 2>/dev/null
  fi
done | sort -rh | head -20

# Empty dirs
find /home/USER -maxdepth 2 -type d -empty 2>/dev/null | grep -v ".cache" | head -20

# Stale backup/temp files
find /home/USER -maxdepth 4 -type f \( -name "*.bak" -o -name "*.old" -o -name "*~" -o -name "*.swp" \) 2>/dev/null

# Old browser/Electron cache
du -sh ~/.cache/mozilla ~/.cache/google-chrome ~/.cache/ms-playwright ~/.cache/puppeteer ~/.cache/electron ~/.cache/wine ~/.cache/winetricks 2>/dev/null
```

### Step 2: Present Findings

Group by confidence level:
- **Safe to nuke** — definite leftovers (dead app configs, Wine cache after prefix deleted, .bak files)
- **Probably safe but check** — user might be using (Playwright, Akonadi, Baloo)
- **Not touching** — active apps, standard Linux dirs

### Step 3: Ask About Ambiguous Items

Key questions:
- "Do you use Playwright/Puppeteer?" (can be 1.3G+ in cache)
- "Are you using KDE apps?" (Akonadi/Baloo are KDE-specific, 170M combined)
- Any app where intent is unclear

---

## Pitfalls

- `paccache` requires `pacman-contrib` package (pre-installed on CachyOS, may not be on vanilla Arch)
- Running `paccache` without `sudo` fails silently on permissions
- `npm cache clean --force` prints a warning about protections being disabled — this is normal
- Wine prefixes can be large (500M-1G) even with no apps installed — just the Windows skeleton takes space
- After cleaning pacman cache, `pacman -Sc` (lowercase) only removes old versions; `-Scc` (double) removes everything including currently-installed package copies
- **Discord channel deletion via bot requires `MANAGE_CHANNELS` permission.** The `discord_admin` toolset has no delete_channel action — must use the Discord REST API directly (`DELETE /channels/{id}`). If the bot lacks the permission, returns 401 Unauthorized. User has to delete manually or grant the permission first.
- **Check existing tools before installing new ones.** Before installing a headless/CLI variant of software (e.g. qbittorrent-nox when qbittorrent GUI is already installed), check if the existing version already has CLI capabilities: `<binary> --help`. Installing a variant when the existing one suffices creates unnecessary cleanup work.
- **Thorough software removal requires checking shared state.** When removing a software variant that shares config/data dirs with another installed version (e.g. qbittorrent-nox shares `~/.config/qBittorrent/` and `~/.local/share/qBittorrent/` with the GUI version), the removal must clean up ONLY the variant's additions — not the other version's data. Check for: (1) config settings you added for the variant (e.g. WebUI settings), (2) leftover session state (BT_backup fast resume files) that can confuse other instances, (3) partial downloads. A leftover fast resume file from a removed variant caused the GUI version to fail with "mismatching file size" errors until the BT_backup was purged.
