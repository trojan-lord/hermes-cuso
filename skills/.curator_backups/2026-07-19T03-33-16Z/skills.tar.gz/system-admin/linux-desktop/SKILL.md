---
name: linux-desktop
description: "Wayland/Linux desktop troubleshooting — notification conflicts, compositor config, shell integration, service management. Load when user reports UI oddities, missing features, or desktop environment issues on Linux."
tags: [linux, wayland, niri, hyprland, desktop, troubleshooting, notifications, systemd]
---

# Linux Desktop Troubleshooting

Diagnostic and repair workflows for Linux desktop environments, especially Wayland compositors (Niri, Hyprland, Sway) with shell overlays (Noctalia, Quickshell, eww).

---

## Diagnostic Pattern: Notification Conflicts

**Trigger:** User reports notifications looking wrong, appearing twice, or not appearing at all.

**Root cause:** Two notification daemons claiming `org.freedesktop.Notifications` on D-Bus simultaneously. Common on Niri where `mako` is an optional dependency that auto-starts via systemd, but the shell (Noctalia/Quickshell) has its own built-in notification system.

### Step-by-step diagnosis

1. **Check which notification daemons are running:**
   ```bash
   ps aux | grep -iE 'notif|dunst|mako|swaync|fnott' | grep -v grep
   ```

2. **Check who owns the D-Bus notification interface:**
   ```bash
   busctl --user list | grep -i notif
   ```
   Look for `org.freedesktop.Notifications` — whoever owns it is intercepting notifications.

3. **Check if the shell has its own notification system enabled:**
   ```bash
   # Noctalia
   cat ~/.config/noctalia/settings.json | grep -A5 '"notifications"'
   # Quickshell-based shells
   grep -r "notification" ~/.config/quickshell/ --include="*.qml" -l
   ```

4. **Check systemd user services for auto-started daemons:**
   ```bash
   systemctl --user list-units --type=service | grep -iE 'notif|mako|dunst'
   systemctl --user cat mako.service  # check if preset-enabled
   ```

5. **Check when the conflicting daemon was installed:**
   ```bash
   grep -A2 "installed <daemon>" /var/log/pacman.log
   ```
   Often installed as an optional dependency in a bulk package install.

### Fix

Stop and disable the conflicting daemon. The shell's built-in system should reclaim the D-Bus bus on next login (or restart the shell process).

```bash
systemctl --user stop mako.service
systemctl --user disable mako.service
```

### Verification

After disabling the conflicting daemon, confirm the shell reclaimed the bus:

```bash
busctl --user list | grep org.freedesktop.Notifications
```

The owning process should now be `qs` (Noctalia/Quickshell), not `mako`. If the shell auto-reclaimed, no restart needed. Test with:

```bash
notify-send "test" "Notifications working"
```

If the shell did NOT reclaim the bus, restart it or log out/in.

### Pitfall

- `mako` is listed as `Optional For: niri` in pacman. It gets pulled in during bulk niri/sway installs (e.g. `pacman -S niri` or the `cachyos-niri-noctalia` group) and starts automatically via a preset-enabled systemd user service. Users often don't realize it's running.
- Killing the daemon without disabling it (`systemctl --user disable`) will cause it to restart on next login.
- Some shells (Noctalia) only register as the notification server on startup — if mako grabs the bus first, the shell's notification UI never activates. However, Noctalia's Quickshell process often auto-reclaims the bus when mako releases it, so a full restart is not always needed. Check `busctl` before assuming a restart is required.
- The package `cachyos-niri-noctalia` provides Niri config + Noctalia settings. It does NOT pull in mako — mako comes from the separate `niri` optional deps.

**See also:** `references/noctalia-notification-architecture.md` for full details on the notification flow, config paths, `notify-send` usage, and failure modes.

---

## Diagnostic Pattern: notify-send Timeout (Shell Not Running)

**Trigger:** `notify-send` hangs and eventually times out with no error message. No notifications appear. This is **distinct from the daemon-conflict pattern above** — here, nobody owns the bus at all.

### Root cause

The Quickshell/Noctalia process is not running, so no process claims `org.freedesktop.Notifications` on D-Bus. `notify-send` waits for a reply that never comes.

### Step-by-step diagnosis

1. **Check if the shell process exists:**
   ```bash
   pgrep -a "quickshell|qs" || echo "NO SHELL PROCESS RUNNING"
   ```

2. **Verify no one owns the notification bus:**
   ```bash
   busctl --user list | grep org.freedesktop.Notifications
   # No output = no owner = shell not running
   ```

3. **Check how the shell is supposed to start:**
   ```bash
   # Niri
   grep -i "qs\|quickshell\|noctalia" ~/.config/niri/cfg/autostart.kdl
   # Hyprland
   grep -i "qs\|quickshell\|noctalia" ~/.config/hypr/hyprland.conf
   # Systemd (deprecated in newer versions)
   systemctl --user list-unit-files | grep -iE 'noctalia|quickshell'
   ```

### Fix

Start the shell:
```bash
qs -c noctalia-shell &
```
Once the Quickshell process starts and claims `org.freedesktop.Notifications`, `notify-send` will work immediately.

### Pitfall

- This is often confused with the daemon-conflict scenario. If `busctl` shows `qs` already owns the bus but notifications still fail, look at the conflict pattern instead.
- The `systemd` slice `app-dbus\x3a1.1-org.freedesktop.Notifications.slice` may appear in `systemctl` output as inactive — this is normal when no notification daemon is active, and does NOT mean the bus is blocked.
- On Niri, `qs -c noctalia-shell` is launched via `spawn-sh-at-startup` in `~/.config/niri/cfg/autostart.kdl`. If niri is running but the shell didn't start, check for errors in `journalctl --user` or run `qs -c noctalia-shell` manually to see output.
- **There is no `noctalia-cli` or custom notification CLI.** `notify-send` is the only way. Do not look for a Noctalia-specific tool.

---

## Diagnostic Pattern: Service and Process Conflicts

**General pattern for any "something looks wrong" desktop issue:**

1. What processes are running that could be responsible?
2. What D-Bus services are claimed?
3. What systemd user services are enabled/active?
4. What was recently installed or changed? (`/var/log/pacman.log`, `journalctl --user`)
5. What does the shell/compositor config expect vs what is actually running?

---

## Diagnostic Pattern: Hermes Gateway — Connected but Silent

**Trigger:** Hermes Discord (or other platform) bot appears online, sends startup notifications, but never responds to user messages.

### Symptoms
- `hermes gateway status` shows active/running
- Gateway logs show "Connected as <bot>" and startup notification sent
- Log file timestamp stops updating (no new entries for 10+ minutes)
- Earlier logs may show: "Discord messages are being denied because no allowlist is configured"
- `/proc/<pid>/environ` may be missing env vars that are present in `~/.hermes/.env`

### Diagnosis

1. **Check if the log file is still updating:**
   ```bash
   ls -la ~/.hermes/logs/gateway.log; sleep 5; ls -la ~/.hermes/logs/gateway.log
   ```
   If the timestamp didn't change, the event loop is stuck.

2. **Check for allowlist warnings in gateway logs:**
   ```bash
   grep -i "denied\|allowlist\|allow" ~/.hermes/logs/gateway.log | tail -5
   ```

3. **Check if env vars reached the process:**
   ```bash
   cat /proc/$(pgrep -f "gateway run")/environ | tr '\0' '\n' | grep DISCORD
   ```
   If DISCORD vars are missing but the token works (bot connected), dotenv loaded the token but the allowlist vars aren't reaching the adapter.

### Fix

Restart the gateway cleanly — this forces a full env reload:
```bash
hermes gateway restart
```

Do NOT just `systemctl --user restart hermes-gateway` — the `hermes gateway restart` command handles graceful shutdown and reconnection.

### Verification

After restart, confirm the allowlist warning is gone and the log is updating:
```bash
tail -5 ~/.hermes/logs/gateway.log
```
Send a test message on Discord and watch for new log entries.

### Pitfall
- The systemd service file (`~/.config/systemd/user/hermes-gateway.service`) does NOT source `~/.hermes/.env` directly — Hermes loads dotenv programmatically at startup. If the gateway was started by systemd but dotenv loading failed or was partial, the process runs with incomplete env vars. The bot token might load (from config.yaml or partial dotenv) while allowlist vars don't.
- A gateway that shows "Connected" in logs but has a stale log timestamp is effectively dead — the Discord websocket may be up but the message processing loop is not running.
- The restart loop (`RestartForceExitStatus=75` in the service file) can cause rapid restart cycling if the gateway exits with status 75 (TEMPFAIL). Check `journalctl --user -u hermes-gateway` for crash loops.

---

Related: `references/system-state-tools.md` for quick reference on querying desktop state (niri msg, brightnessctl, wpctl, playerctl, gammastep, ydotool).

## Common Packages and Their Roles

| Package | Role | Conflict Risk |
|---------|------|---------------|
| `mako` | Notification daemon | Conflicts with shell built-in notification systems |
| `dunst` | Notification daemon | Same as mako |
| `swaybg` | Wallpaper setter | May conflict with shell wallpaper modules |
| `waybar` | Status bar | May conflict with shell bar widgets |
| `fuzzel` | App launcher | May conflict with shell launcher widgets |
| `swaylock` | Screen locker | May conflict with shell lock screen |

On Noctalia/Quickshell setups, the shell handles most of these functions natively. External tools should be disabled unless specifically needed.
